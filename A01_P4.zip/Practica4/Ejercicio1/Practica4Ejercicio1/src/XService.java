public class XService implements X{
    @Override
    public void rutina1() {
        System.out.println("Codigo rutina numero 1");
    }

    @Override
    public void rutina2() {
        System.out.println("Codigo rutina numero 2");
    }

    @Override
    public void rutina3() {
        System.out.println("Codigo rutina numero 3");
    }

    @Override
    public void rutina4() {
        System.out.println("Codigo rutina numero 4");
    }
}
