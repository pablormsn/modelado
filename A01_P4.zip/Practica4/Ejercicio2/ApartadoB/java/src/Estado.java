public interface Estado {
    //Metodos que van a tener que implementar las clases que implementen esta interfaz
    void abrir(Dispositivo dispositivo);
    void cerrar(Dispositivo dispositivo);
}