public interface EstadoDispositivo {
    void abrirDispositivo(Dispositivo dispositivo, Estado estado);
    void cerrarDispositivo(Dispositivo dispositivo, Estado estado);
}
