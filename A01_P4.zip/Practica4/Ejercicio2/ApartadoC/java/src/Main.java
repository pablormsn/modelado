public class Main {
    public static void main(String[] args) {
        Biestable dispositivo = new Biestable();
        dispositivo.estado();
        dispositivo.abrir();
        dispositivo.estado();
        dispositivo.cerrar();
        dispositivo.estado();
        dispositivo.cambio();
        dispositivo.estado();
        dispositivo.abrir();
        dispositivo.estado();
        dispositivo.abrir();
        dispositivo.estado();
        dispositivo.cerrar();
        dispositivo.estado();
        dispositivo.abrir();
        dispositivo.estado();
        dispositivo.cerrar();
        dispositivo.estado();
        dispositivo.cerrar();
        dispositivo.estado();

    }
}
