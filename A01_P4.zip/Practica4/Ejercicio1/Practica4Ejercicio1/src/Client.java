public interface Client {

    public void rutina1();
    public void rutina2();
    public void rutina3();
    public void rutina4();
}
