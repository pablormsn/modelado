import java.util.List;

interface SortingStrategy {
    void sort(List<Email> email);
}
