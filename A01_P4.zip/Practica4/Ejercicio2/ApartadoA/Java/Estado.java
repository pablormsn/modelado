package Java;

public interface Estado {
    //Metodos que van a tener que implementar las clases que implementen esta interfaz
    public void abrir(Biestable biestable);
    public void cerrar(Biestable biestable);
}