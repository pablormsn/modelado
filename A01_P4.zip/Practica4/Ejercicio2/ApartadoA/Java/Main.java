package Java;

public class Main {
    public static void main(String[] args) {
        Biestable biestable = new Biestable();
        biestable.estado();
        biestable.abrir();
        biestable.estado();
        biestable.cerrar();
        biestable.estado();
    }
}
