public interface Mediador {
    void abrirDispositivo(Dispositivo dispositivo, Estado estado);
    void cerrarDispositivo(Dispositivo dispositivo, Estado estado);
}
